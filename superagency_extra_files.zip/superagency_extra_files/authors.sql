
DROP TABLE IF EXISTS "authors";
CREATE TABLE IF NOT EXISTS "authors" (
    "id" INTEGER PRIMARY KEY NOT NULL,
    "full_name" TEXT NOT NULL COLLATE NOCASE,
    "github_username" TEXT NOT NULL COLLATE NOCASE,
    "edx_username" TEXT NOT NULL COLLATE NOCASE,
    "city" TEXT NOT NULL COLLATE NOCASE,
    "country" TEXT NOT NULL COLLATE NOCASE
);


INSERT INTO "authors" VALUES
(1,'Damián Ferrero', 'Damocode', 'DAMOenlaWeb', 'Buenos Aires', 'Argentina'),
(2,'Eva Nikoghosyan', 'eva-niko', 'EVA_NIKO', 'Buenos Aires', 'Argentina');

SELECT * FROM "authors";
